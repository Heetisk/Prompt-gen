"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { enhancePrompt } from '@/lib/prompt-enhancer';
import { toast } from 'sonner';
import { Lightbulb, Code, ArrowRight, Loader2 } from 'lucide-react';

export function PromptEnhancer() {
  const [basicPrompt, setBasicPrompt] = useState('');
  const [enhancedPrompt, setEnhancedPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!basicPrompt.trim()) {
      toast.error("Please enter a prompt to enhance");
      return;
    }

    setIsLoading(true);

    try {
      const result = await enhancePrompt(basicPrompt);
      setEnhancedPrompt(result);
      toast.success("Prompt enhanced successfully!");
    } catch (error) {
      toast.error("Failed to enhance prompt. Please try again.");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (enhancedPrompt) {
      navigator.clipboard.writeText(enhancedPrompt);
      toast.success("Copied to clipboard");
    }
  };

  const insertExample = (example: string) => {
    setBasicPrompt(example);
  };

  // Example prompts to help users understand the tool
  const examples = [
    "Explain machine learning to a high school student",
    "How to grow tomatoes in a small garden",
    "Compare REST and GraphQL for API development",
    "Write a script to automate file backups"
  ];

  return (
    <div className="space-y-8">
      <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg mb-6">
        <div className="flex items-start space-x-3">
          <Lightbulb className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-medium mb-2">How Our AI Prompt Enhancement Works</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
              Our open-source AI creates a completely customized, topic-specific prompt by:
            </p>
            <ol className="text-sm text-gray-600 dark:text-gray-300 space-y-1 list-decimal list-inside ml-2">
              <li>Analyzing your request to understand the topic and goal</li>
              <li>Creating a customized prompt structure specific to your subject</li>
              <li>Adding domain-specific terminology and relevant context</li>
              <li>Crafting detailed instructions tailored to your exact needs</li>
            </ol>
          </div>
        </div>
      </div>

      <div className="space-y-2 mb-6">
        <h3 className="text-sm font-medium">Try an example:</h3>
        <div className="flex flex-wrap gap-2">
          {examples.map((example) => (
            <Button
              key={example}
              variant="outline"
              size="sm"
              onClick={() => insertExample(example)}
              className="text-xs"
            >
              {example}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Basic Prompt</CardTitle>
            <CardDescription>
              Enter your basic prompt here and we'll transform it into a tailored, topic-specific prompt
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent>
              <Textarea
                placeholder="Enter your prompt here. For example: Explain machine learning to a beginner"
                className="min-h-[200px]"
                value={basicPrompt}
                onChange={(e) => setBasicPrompt(e.target.value)}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading} className="w-full">
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Enhancing...
                  </>
                ) : (
                  <>
                    Enhance Prompt
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Enhanced Prompt</CardTitle>
            <CardDescription>
              Your custom-crafted, topic-specific prompt will appear here
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Your enhanced prompt will appear here..."
              className="min-h-[200px] font-mono text-sm"
              value={enhancedPrompt}
              readOnly
            />
            <div className="mt-4 text-xs text-gray-500 dark:text-gray-400 space-y-2">
              <p className="flex items-center">
                <Code className="h-4 w-4 mr-2" />
                <span>This enhanced prompt is custom-designed for your specific topic</span>
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button
              variant="secondary"
              onClick={handleCopy}
              disabled={!enhancedPrompt}
              className="w-full"
            >
              Copy to Clipboard
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-8 p-4 border border-gray-200 dark:border-gray-800 rounded-lg">
        <h3 className="font-medium mb-2">Why Use Topic-Specific Custom Prompts?</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
          Custom-designed prompts tailored to your exact topic provide significantly better results:
        </p>
        <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-2 list-disc list-inside ml-2">
          <li>Addresses the unique aspects of your specific subject matter</li>
          <li>Includes domain-specific terminology and concepts relevant to your topic</li>
          <li>Creates a prompt structure optimized for your particular request type</li>
          <li>Increases the relevance and quality of AI responses by focusing on what matters most</li>
        </ul>
      </div>
    </div>
  );
}
