"use client";

import { Button } from '@/components/ui/button';

export function Hero() {
  const scrollToPromptEnhancer = () => {
    const enhancerElement = document.getElementById('prompt-enhancer');
    if (enhancerElement) {
      enhancerElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Enhance Your AI Prompts
            </h1>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Transform basic prompts into detailed, structured instructions that get better results from AI models. Powered by Heetisk.
            </p>
          </div>
          <div className="space-x-4">
            <Button size="lg" onClick={scrollToPromptEnhancer}>
              Try It Now
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="/about">Learn More</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
