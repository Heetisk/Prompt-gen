import Link from 'next/link';

export function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Heetisk</h3>
            <p className="text-sm text-muted-foreground">
              Transform basic prompts into advanced, detailed instructions for better AI results.
            </p>
          </div>
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Navigation</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  About
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Contact</h3>
            <ul className="space-y-2">
              <li className="text-sm text-muted-foreground">
                <span className="font-medium">Email:</span>{' '}
                <a href="mailto:hitlimbani6@gmail.com" className="hover:text-foreground transition-colors">
                  hitlimbani6@gmail.com
                </a>
              </li>
              <li className="text-sm text-muted-foreground">
                <span className="font-medium">Phone:</span>{' '}
                <a href="tel:+919328800629" className="hover:text-foreground transition-colors">
                  +91 9328800629
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Heetisk. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
