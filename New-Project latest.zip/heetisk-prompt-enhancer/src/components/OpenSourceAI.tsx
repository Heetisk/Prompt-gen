import { Rocket, Github, Code2, Server, Puzzle, Zap } from 'lucide-react';

export function OpenSourceAI() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 border-t">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Powered by Open-Source AI</h2>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Heetisk Prompt Enhancer uses Ollama, a powerful open-source AI framework, to create custom prompts
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 mt-8 max-w-[1000px]">
            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-200 p-6 shadow-sm transition-all hover:shadow-md dark:border-gray-800">
              <div className="rounded-full bg-blue-100 p-3 dark:bg-blue-900/20">
                <Github className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Open Source</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                Our prompt enhancement is built using Ollama, an entirely open-source AI framework that allows for local execution of large language models without sending your data to third-party services.
              </p>
            </div>

            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-200 p-6 shadow-sm transition-all hover:shadow-md dark:border-gray-800">
              <div className="rounded-full bg-blue-100 p-3 dark:bg-blue-900/20">
                <Server className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Self-Hosted</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                We run our own Ollama instance on secure servers, ensuring that your prompt data is processed with privacy in mind. The API is accessible only to our application, maintaining data security.
              </p>
            </div>

            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-200 p-6 shadow-sm transition-all hover:shadow-md dark:border-gray-800">
              <div className="rounded-full bg-blue-100 p-3 dark:bg-blue-900/20">
                <Code2 className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Advanced Models</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                Ollama provides access to state-of-the-art language models like Llama3, which we use to analyze your requests and generate custom-designed prompts specific to your topic.
              </p>
            </div>

            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-200 p-6 shadow-sm transition-all hover:shadow-md dark:border-gray-800">
              <div className="rounded-full bg-blue-100 p-3 dark:bg-blue-900/20">
                <Puzzle className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Topic-Specific Design</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                Unlike template-based enhancers, our AI creates completely custom prompt structures tailored to the specific subject matter of your request, incorporating domain-specific knowledge.
              </p>
            </div>

            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-200 p-6 shadow-sm transition-all hover:shadow-md dark:border-gray-800">
              <div className="rounded-full bg-blue-100 p-3 dark:bg-blue-900/20">
                <Zap className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Multi-Stage Processing</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                Our system uses a sophisticated multi-stage approach, first analyzing your request to understand the topic and goal, then crafting a custom prompt structure optimized for your specific need.
              </p>
            </div>

            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-200 p-6 shadow-sm transition-all hover:shadow-md dark:border-gray-800">
              <div className="rounded-full bg-blue-100 p-3 dark:bg-blue-900/20">
                <Rocket className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">Fallback System</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                Our application includes an intelligent fallback system with multiple tiers of capability, ensuring that you'll always get enhanced prompts even if the primary AI system is temporarily unavailable.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
