import { Sparkles, MessageSquare, Zap, Clock } from 'lucide-react';

export function Features() {
  const features = [
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "Simple Input",
      description: "Enter your basic prompt in plain language. No complex formatting required."
    },
    {
      icon: <Sparkles className="h-6 w-6" />,
      title: "AI Enhancement",
      description: "Our algorithm analyzes your prompt and adds structure, specificity, and context."
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Better Results",
      description: "Enhanced prompts lead to more accurate, relevant, and detailed AI responses."
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Save Time",
      description: "Eliminate back-and-forth refinements with AI models by starting with a better prompt."
    }
  ];

  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">How It Works</h2>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Transform your basic prompts into detailed instructions in seconds
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 mt-8">
            {features.map((feature) => (
              <div key={feature.title} className="flex flex-col items-center space-y-2 rounded-lg border border-gray-200 p-6 shadow-sm transition-all hover:shadow-md dark:border-gray-800">
                <div className="rounded-full bg-blue-100 p-3 dark:bg-blue-900/20">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-bold">{feature.title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
