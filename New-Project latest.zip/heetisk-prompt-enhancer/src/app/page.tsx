import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Hero } from "@/components/Hero";
import { Features } from "@/components/Features";
import { PromptEnhancer } from "@/components/PromptEnhancer";
import { OpenSourceAI } from "@/components/OpenSourceAI";

export default function Home() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <Hero />
        <Features />
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50 dark:bg-gray-900/50" id="prompt-enhancer">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Try It Yourself</h2>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                  Enter your basic prompt below and see how we enhance it
                </p>
              </div>
            </div>
            <PromptEnhancer />
          </div>
        </section>
        <OpenSourceAI />
      </main>
      <Footer />
    </>
  );
}
