import type { Metadata } from "next";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata: Metadata = {
  title: "About - Heetisk Prompt Enhancer",
  description: "Learn more about Heetisk's AI prompt enhancement service",
};

export default function AboutPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-[800px] space-y-12">
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About Heetisk</h1>
                <p className="text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                  Heetisk provides advanced tools for improving AI interactions, with a focus on enhancing prompt engineering.
                </p>
              </div>

              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Our Mission</h2>
                <p className="text-gray-500 dark:text-gray-400">
                  At Heetisk, we believe that effective communication with AI systems starts with well-crafted prompts.
                  Our mission is to make advanced prompt engineering accessible to everyone, regardless of their technical background.
                </p>
              </div>

              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Open-Source AI Technology</h2>
                <p className="text-gray-500 dark:text-gray-400">
                  We're committed to using open-source AI technology. Our prompt enhancement system is powered by
                  Ollama, an open-source framework for running local language models. This ensures that your prompts
                  are processed in a privacy-preserving manner without relying on closed commercial AI systems.
                </p>
                <p className="text-gray-500 dark:text-gray-400">
                  By using open-source technologies, we maintain full control over how your data is processed and
                  can transparently explain how our systems work. This aligns with our values of transparency and
                  ethical AI use.
                </p>
              </div>

              <div className="space-y-4">
                <h2 className="text-2xl font-bold">How Our Prompt Enhancer Works</h2>
                <p className="text-gray-500 dark:text-gray-400">
                  The Heetisk Prompt Enhancer uses Ollama's AI capabilities to transform basic prompts into structured, detailed instructions.
                  By analyzing your input, we add context, specificity, and formatting guidelines that help AI models understand
                  exactly what you're looking for.
                </p>
                <p className="text-gray-500 dark:text-gray-400">
                  Our enhancement templates are based on best practices from prompt engineering research, ensuring that you get
                  more accurate, relevant, and helpful responses from any AI system.
                </p>
              </div>

              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Contact Information</h2>
                <p className="text-gray-500 dark:text-gray-400">
                  If you have any questions, feedback, or suggestions about our prompt enhancement service, please don't hesitate to reach out:
                </p>
                <ul className="space-y-2 text-gray-500 dark:text-gray-400">
                  <li>
                    <span className="font-medium">Email:</span>{' '}
                    <a href="mailto:hitlimbani6@gmail.com" className="underline underline-offset-2">
                      hitlimbani6@gmail.com
                    </a>
                  </li>
                  <li>
                    <span className="font-medium">Phone:</span>{' '}
                    <a href="tel:+919328800629" className="underline underline-offset-2">
                      +91 9328800629
                    </a>
                  </li>
                </ul>
              </div>

              <div className="flex justify-center">
                <Button asChild>
                  <Link href="/">
                    Try the Prompt Enhancer
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
