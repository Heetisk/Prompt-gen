/**
 * Enhanced prompt generator with Ollama AI integration
 */

// Ollama API configuration
const OLLAMA_API_ENDPOINT = 'https://ollama-api.heetisk.com/api/generate'; // Replace with your actual Ollama API endpoint
const OLLAMA_MODEL = 'llama3'; // Or your preferred model

/**
 * Enhance a basic prompt using Ollama AI
 * @param basicPrompt The user's basic prompt to enhance
 * @returns A completely new, enhanced prompt specific to the topic
 */
export async function enhancePrompt(basicPrompt: string): Promise<string> {
  try {
    // Try to use the Ollama API to generate a completely new prompt
    try {
      const response = await generateTopicSpecificPrompt(basicPrompt);
      if (response) {
        return response;
      }
    } catch (ollamaError) {
      console.warn("Ollama API call failed for custom prompt generation:", ollamaError);
      // Proceed to fallback approach
    }

    // Fallback: Try simplified prompt generation
    try {
      const fallbackResponse = await generateSimplifiedPrompt(basicPrompt);
      if (fallbackResponse) {
        return fallbackResponse;
      }
    } catch (fallbackError) {
      console.warn("Simplified prompt generation failed:", fallbackError);
      // Proceed to final fallback
    }

    // Final fallback: Generate a basic enhanced prompt without API
    return generateBasicPrompt(basicPrompt);
  } catch (error) {
    console.error("Error enhancing prompt:", error);
    return "Error enhancing prompt. Please try again.";
  }
}

/**
 * Generate a completely new, topic-specific prompt
 * @param basicPrompt The user's basic prompt
 * @returns A tailored, in-depth prompt specific to the topic
 */
async function generateTopicSpecificPrompt(basicPrompt: string): Promise<string | null> {
  try {
    const systemPrompt = `You are an expert prompt engineer. Your task is to transform a user's simple prompt into a powerful, detailed prompt that will get optimal results from AI systems.

DO NOT use a template. Instead, analyze the topic and create a fully custom prompt structure that is specifically designed for this particular subject matter and request type.

Follow these principles:
1. Thoroughly analyze the user's request to understand the underlying goal
2. Identify the subject domain and the type of response needed
3. Create a detailed, custom-structured prompt that is perfectly suited to this specific topic
4. Include relevant domain-specific terminology and concepts
5. Add appropriate constraints, format requirements, and evaluation criteria
6. If relevant, include example formats or reference patterns

IMPORTANT INSTRUCTIONS:
- Your response should ONLY contain the enhanced prompt, nothing else.
- The enhanced prompt should be 3-5 times more detailed than the original.
- The prompt should read as a coherent set of instructions to an AI, not as a filled-in template.
- The final prompt should include specific details about the subject matter mentioned in the user's request.
- Make the prompt substantive, informative, and specific to the topic.
- Include domain-specific guidance that shows deep understanding of the subject.`;

    // Call the Ollama API
    const response = await fetch(OLLAMA_API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        system: systemPrompt,
        prompt: `Please transform this simple prompt into a comprehensive, topic-specific prompt: "${basicPrompt}"`,
        stream: false,
        options: {
          temperature: 0.7,
          top_p: 0.9,
          max_tokens: 1000,
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama API responded with status: ${response.status}`);
    }

    const data = await response.json();
    return data.response || null;
  } catch (error) {
    console.error('Error generating topic-specific prompt:', error);
    return null;
  }
}

/**
 * Generate a simplified but still customized prompt as a fallback
 * @param basicPrompt The user's basic prompt
 * @returns A simplified but enhanced prompt
 */
async function generateSimplifiedPrompt(basicPrompt: string): Promise<string | null> {
  try {
    const systemPrompt = `You are a prompt improvement expert. Your task is to transform a simple user request into a more effective prompt for an AI system.

Create a prompt that:
1. Clearly specifies what information is needed
2. Includes relevant context about the topic
3. Indicates the desired format and level of detail
4. Adds any necessary constraints or requirements

Keep it relatively concise but much more detailed than the original. Focus on the specific subject matter in the user's request.

Your response should ONLY contain the improved prompt, nothing else.`;

    // Call the Ollama API
    const response = await fetch(OLLAMA_API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        system: systemPrompt,
        prompt: `Improve this prompt: "${basicPrompt}"`,
        stream: false,
        options: {
          temperature: 0.6,
          max_tokens: 500,
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama API responded with status: ${response.status}`);
    }

    const data = await response.json();
    return data.response || null;
  } catch (error) {
    console.error('Error generating simplified prompt:', error);
    return null;
  }
}

/**
 * Generate a basic enhanced prompt without using the API
 * @param basicPrompt The user's basic prompt
 * @returns A modestly enhanced prompt
 */
function generateBasicPrompt(basicPrompt: string): string {
  // Extract the main topic or subject
  const topic = extractMainTopic(basicPrompt);

  // Determine what kind of task this is
  const taskType = determineTaskType(basicPrompt);

  // Generate a prompt based on the task type
  switch (taskType) {
    case 'explanation':
      return `Provide a comprehensive explanation of ${topic} that covers the key concepts, important principles, and practical applications. Include relevant examples to illustrate complex points, and explain any technical terminology in accessible language. Structure your response with clear sections for different aspects of the topic, and conclude with a summary of the most important points to remember.`;

    case 'howto':
      return `Provide a detailed step-by-step guide on how to ${topic}. For each step, explain the purpose, potential challenges, and best practices. Include prerequisites, required tools or resources, and troubleshooting tips for common issues. Where relevant, provide alternative approaches and explain the trade-offs. Conclude with advice on how to verify successful completion and next steps to take.`;

    case 'comparison':
      return `Compare and contrast the key aspects of ${topic}. Analyze their similarities and differences across important dimensions such as features, performance, use cases, advantages, and limitations. Present the information in a structured format that clearly highlights the points of comparison. Include practical considerations for choosing between them in different scenarios, and support your analysis with specific examples where possible.`;

    case 'list':
      return `Provide a comprehensive list of ${topic}. For each item, include a detailed description, key characteristics, and notable examples or applications. Organize the list in a logical order (e.g., importance, chronology, or complexity) and explain the rationale for this organization. Ensure coverage is thorough and includes both common and less well-known items. Where appropriate, include brief context about why each item is significant.`;

    case 'analysis':
      return `Conduct an in-depth analysis of ${topic}, examining its key components, underlying principles, and broader implications. Consider multiple perspectives and potential interpretations. Identify strengths, weaknesses, opportunities, and challenges related to the topic. Support your analysis with relevant evidence, examples, or case studies. Conclude with insights about the significance of your findings and potential future developments.`;

    case 'creative':
      return `Create an original and engaging ${topic} that demonstrates creativity, imagination, and attention to detail. Ensure the creation has a clear structure, purpose, and audience in mind. Incorporate elements that make it distinctive and memorable, while maintaining coherence and quality throughout. Consider innovative approaches or unique perspectives that could set this creation apart. If appropriate, include reflections on the creative choices made and their intended impact.`;

    default:
      // General purpose enhanced prompt
      return `Provide a detailed and well-structured response about ${topic}. Include key information, relevant examples, and practical applications. Consider different perspectives and approaches where appropriate. Present the information in a clear, logical format with appropriate headings or sections. Define any specialized terminology, and ensure your response is comprehensive while remaining focused on the most important aspects of the topic.`;
  }
}

/**
 * Extract the main topic from a prompt
 */
function extractMainTopic(prompt: string): string {
  // Remove question words and common prompt starters
  const cleanedPrompt = prompt
    .replace(/^(explain|describe|tell me about|what is|how to|how do i|can you|please|I need|give me|provide|create|write|generate|list)/i, '')
    .trim();

  // If the prompt is short, return it as is
  if (cleanedPrompt.length < 50) {
    return cleanedPrompt;
  }

  // Otherwise, try to extract the main subject
  const firstSentence = cleanedPrompt.split(/[.!?]/).filter(s => s.trim().length > 0)[0] || cleanedPrompt;

  // Return the first sentence or a portion of it
  return firstSentence.length > 100 ? firstSentence.substring(0, 100) + '...' : firstSentence;
}

/**
 * Determine the type of task the prompt is asking for
 */
function determineTaskType(prompt: string): string {
  const lowerPrompt = prompt.toLowerCase();

  // Check for explanation requests
  if (lowerPrompt.includes('explain') || lowerPrompt.includes('what is') ||
      lowerPrompt.includes('describe') || lowerPrompt.includes('tell me about')) {
    return 'explanation';
  }

  // Check for how-to requests
  if (lowerPrompt.includes('how to') || lowerPrompt.includes('steps to') ||
      lowerPrompt.includes('guide') || lowerPrompt.includes('instructions')) {
    return 'howto';
  }

  // Check for comparison requests
  if (lowerPrompt.includes('compare') || lowerPrompt.includes('difference between') ||
      lowerPrompt.includes('vs') || lowerPrompt.includes('versus') ||
      lowerPrompt.includes('similarities') || lowerPrompt.includes('differences')) {
    return 'comparison';
  }

  // Check for list requests
  if (lowerPrompt.includes('list') || lowerPrompt.includes('enumerate') ||
      lowerPrompt.includes('examples of') || lowerPrompt.includes('types of')) {
    return 'list';
  }

  // Check for analysis requests
  if (lowerPrompt.includes('analyze') || lowerPrompt.includes('examine') ||
      lowerPrompt.includes('investigate') || lowerPrompt.includes('evaluate')) {
    return 'analysis';
  }

  // Check for creative requests
  if (lowerPrompt.includes('create') || lowerPrompt.includes('write') ||
      lowerPrompt.includes('generate') || lowerPrompt.includes('develop') ||
      lowerPrompt.includes('design') || lowerPrompt.includes('compose')) {
    return 'creative';
  }

  // Default task type
  return 'general';
}
